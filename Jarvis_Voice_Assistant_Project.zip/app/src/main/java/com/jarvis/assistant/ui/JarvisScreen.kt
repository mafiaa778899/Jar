package com.jarvis.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.R
import com.jarvis.assistant.viewmodel.JarvisViewModel

@Composable
fun JarvisScreen(viewModel: JarvisViewModel) {
    val status by viewModel.status.collectAsState()
    val isActive by viewModel.isActive.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    var showSettingsDialog by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "reactor_anim")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isActive) 1200 else 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = if (isActive) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isActive) 700 else 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03080F))
    ) {
        // 1. Center Background Image
        Image(
            painter = painterResource(id = R.drawable.ironman_bg),
            contentDescription = "Iron Man HUD",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )

        // 2. Interactive Animated Arc Reactor Core
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 115.dp)
                .size(110.dp)
                .scale(pulseScale)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    viewModel.toggleJarvis()
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = if (isActive) listOf(
                                Color(0xFF00E5FF).copy(alpha = 0.6f),
                                Color(0xFF0077FF).copy(alpha = 0.2f),
                                Color.Transparent
                            ) else listOf(
                                Color(0xFF00B0FF).copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .rotate(rotation)
                    .border(
                        width = if (isActive) 3.dp else 1.5.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFF00FFFF),
                                Color.Transparent,
                                Color(0xFF00E5FF),
                                Color.Transparent,
                                Color(0xFF00FFFF)
                            )
                        ),
                        shape = CircleShape
                    )
            )

            Box(
                modifier = Modifier
                    .size(45.dp)
                    .rotate(-rotation * 1.5f)
                    .border(
                        width = 2.dp,
                        color = if (isActive) Color(0xFFE0F7FA) else Color(0xFF00B0FF),
                        shape = CircleShape
                    )
            )

            Box(
                modifier = Modifier
                    .size(20.dp)
                    .background(
                        if (isActive) Color(0xFFFFFFFF) else Color(0xFF80D8FF),
                        shape = CircleShape
                    )
            )
        }

        // 3. Top Header HUD Status & Settings
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 20.dp, end = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "J.A.R.V.I.S // MARK VII",
                    color = Color(0xFF00E5FF),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "STATUS: $status",
                    color = if (isActive) Color(0xFF69F0AE) else Color(0xFF78909C),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }

            IconButton(onClick = { showSettingsDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color(0xFF00E5FF)
                )
            }
        }

        // 4. API Key Settings Dialog
        if (showSettingsDialog) {
            var tempKey by remember { mutableStateOf(apiKey) }
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                containerColor = Color(0xFF0D1B2A),
                titleColor = Color(0xFF00E5FF),
                title = { Text("J.A.R.V.I.S CONFIGURATION", fontFamily = FontFamily.Monospace) },
                text = {
                    Column {
                        Text(
                            "Google AI Studio API Key:",
                            color = Color(0xFFECEFF1),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = tempKey,
                            onValueChange = { tempKey = it },
                            placeholder = { Text("AIzaSy...", color = Color.Gray) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00E5FF),
                                unfocusedBorderColor = Color(0xFF455A64)
                            )
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.saveApiKey(tempKey)
                        showSettingsDialog = false
                    }) {
                        Text("SAVE", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("CANCEL", color = Color.Gray)
                    }
                }
            )
        }
    }
}
