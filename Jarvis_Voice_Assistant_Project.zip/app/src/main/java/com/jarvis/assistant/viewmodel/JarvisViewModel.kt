package com.jarvis.assistant.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.audio.AudioPlayer
import com.jarvis.assistant.audio.AudioRecorder
import com.jarvis.assistant.network.GeminiLiveClient
import com.jarvis.assistant.tools.PhoneActions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    private val _status = MutableStateFlow("STANDBY")
    val status = _status.asStateFlow()

    private val _isActive = MutableStateFlow(false)
    val isActive = _isActive.asStateFlow()

    private val _apiKey = MutableStateFlow(prefs.getString("api_key", "") ?: "")
    val apiKey = _apiKey.asStateFlow()

    private val recorder = AudioRecorder()
    private val player = AudioPlayer()
    private val phoneActions = PhoneActions(application)
    private var client: GeminiLiveClient? = null

    fun saveApiKey(key: String) {
        prefs.edit().putString("api_key", key).apply()
        _apiKey.value = key
    }

    fun toggleJarvis() {
        if (_isActive.value) {
            stop()
        } else {
            start()
        }
    }

    private fun start() {
        if (_apiKey.value.isBlank()) {
            _status.value = "PLEASE ENTER API KEY IN SETTINGS"
            return
        }

        _isActive.value = true
        player.start()

        client = GeminiLiveClient(
            apiKey = _apiKey.value,
            phoneActions = phoneActions,
            onAudioChunk = { pcm -> player.write(pcm) },
            onInterrupt = { player.flush() },
            onStatus = { s -> _status.value = s }
        )

        client?.connect()

        viewModelScope.launch {
            recorder.start { chunk ->
                client?.sendAudio(chunk)
            }
        }
    }

    private fun stop() {
        _isActive.value = false
        _status.value = "STANDBY"
        recorder.stop()
        player.release()
        client?.disconnect()
        client = null
    }

    override fun onCleared() {
        super.onCleared()
        stop()
    }
}
