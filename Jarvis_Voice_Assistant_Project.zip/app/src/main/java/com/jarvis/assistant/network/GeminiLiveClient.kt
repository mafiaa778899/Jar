package com.jarvis.assistant.network

import android.util.Base64
import com.jarvis.assistant.tools.PhoneActions
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiLiveClient(
    private val apiKey: String,
    private val phoneActions: PhoneActions,
    private val onAudioChunk: (ByteArray) -> Unit,
    private val onInterrupt: () -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    private var webSocket: WebSocket? = null

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        onStatus("CALIBRATING...")
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                onStatus("SYSTEM ONLINE")
                sendSetup(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleMessage(ws, text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                onStatus("OFFLINE: ${t.localizedMessage ?: "Check API Key"}")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                onStatus("STANDBY")
            }
        })
    }

    private fun sendSetup(ws: WebSocket) {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", "models/gemini-2.0-flash-exp")
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", "Fenrir")
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().apply {
                        put("text", "You are JARVIS, a concise, highly capable personal AI assistant. You control this Android phone. Always respond verbally in brief sentences, and proactively use function calling tools when asked to send messages, make calls, turn on/off flashlight, check battery, or open apps.")
                    }))
                })
                put("tools", JSONArray().put(JSONObject().apply {
                    put("functionDeclarations", JSONArray().apply {
                        put(createFuncDecl("send_sms", "Send SMS to a contact", listOf("phone", "message")))
                        put(createFuncDecl("make_call", "Make a direct phone call", listOf("phone")))
                        put(createFuncDecl("toggle_flashlight", "Turn torch ON or OFF", listOf("status")))
                        put(createFuncDecl("open_app", "Launch apps like WhatsApp, YouTube, Chrome, Camera", listOf("app_name")))
                        put(createFuncDecl("check_battery", "Get battery percentage", listOf()))
                    })
                }))
            })
        }
        ws.send(setup.toString())
    }

    private fun createFuncDecl(name: String, desc: String, requiredParams: List<String>): JSONObject {
        val properties = JSONObject()
        for (param in requiredParams) {
            properties.put(param, JSONObject().put("type", "STRING"))
        }
        return JSONObject().apply {
            put("name", name)
            put("description", desc)
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", properties)
                put("required", JSONArray(requiredParams))
            })
        }
    }

    fun sendAudio(data: ByteArray) {
        val b64 = Base64.encodeToString(data, Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(JSONObject().apply {
                    put("mimeType", "audio/pcm;rate=16000")
                    put("data", b64)
                }))
            })
        }
        webSocket?.send(payload.toString())
    }

    private fun handleMessage(ws: WebSocket, text: String) {
        val json = JSONObject(text)
        val serverContent = json.optJSONObject("serverContent")

        if (serverContent != null) {
            if (serverContent.optBoolean("interrupted", false)) {
                onInterrupt()
                return
            }

            val modelTurn = serverContent.optJSONObject("modelTurn")
            val parts = modelTurn?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        val audioBytes = Base64.decode(inlineData.getString("data"), Base64.DEFAULT)
                        onAudioChunk(audioBytes)
                    }
                }
            }
        }

        val toolCall = json.optJSONObject("toolCall")
        if (toolCall != null) {
            val functionCalls = toolCall.optJSONArray("functionCalls") ?: return
            val responses = JSONArray()

            for (i in 0 until functionCalls.length()) {
                val call = functionCalls.getJSONObject(i)
                val callId = call.getString("id")
                val name = call.getString("name")
                val argsJson = call.optJSONObject("args")
                val args = mutableMapOf<String, String>()
                argsJson?.keys()?.forEach { key ->
                    args[key] = argsJson.getString(key)
                }

                onStatus("EXECUTING: $name")
                val result = phoneActions.execute(name, args)

                responses.put(JSONObject().apply {
                    put("id", callId)
                    put("name", name)
                    put("response", JSONObject().put("output", result))
                })
            }

            val toolResponsePayload = JSONObject().apply {
                put("toolResponse", JSONObject().put("functionResponses", responses))
            }
            ws.send(toolResponsePayload.toString())
        }
    }

    fun disconnect() {
        webSocket?.close(1000, "Closed")
        webSocket = null
    }
}
