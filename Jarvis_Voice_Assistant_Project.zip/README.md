# J.A.R.V.I.S Voice-to-Voice Assistant (Android)

Native Android Voice-to-Voice Assistant powered by **Google AI Studio (Gemini 2.0 Flash Live API)** and **Jetpack Compose**.

## Features
- **Iron Man HUD UI**: Clean dark interface with an interactive rotating & pulsing Arc Reactor.
- **Voice-to-Voice Real-Time Streaming**: Low-latency 16kHz PCM audio input & 24kHz PCM audio playback via WebSocket.
- **Phone Control**: Supports Function Calling to send SMS, make calls, turn flashlight ON/OFF, launch apps (WhatsApp, YouTube, etc.), and check battery status.
- **In-App API Key Configuration**: Directly enter and update your Google AI Studio API Key in Settings.

## Automatic APK Build via GitHub
1. Upload this repository to GitHub.
2. Go to **Actions** tab.
3. Once the workflow finishes, download `jarvis-voice-assistant-apk` from **Artifacts**.
